import 'dart:ui';
import 'package:flutter/material.dart';

const Color KprimaryColor=Color(0xFF3b5998);
const double Kpadding=20.0;