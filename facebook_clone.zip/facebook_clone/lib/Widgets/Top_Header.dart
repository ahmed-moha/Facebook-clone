import 'package:facebook_clone/export.dart';

class Top_Header extends StatelessWidget {
  
 

  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Row(
      children: [
         Container(
       margin: EdgeInsets.all(Kpadding),
       width: 50,
       height: 50,
       child: CircleAvatar(
         backgroundImage: AssetImage("assets/images/ahmed.jpg"),
       ),
     ),
     Container(
         height: 40,
         width: size.width * 0.7,
         decoration: BoxDecoration(
           borderRadius: BorderRadius.circular(200),
         ),
         child: OutlinedButton(
           onPressed: () {},
           child: Text(
             "What's on your mind?",
             style: TextStyle(color: Colors.black),
           ),
         )),
      ],
    );
  }
}
