import 'package:facebook_clone/export.dart';
class Users_image_with_active extends StatelessWidget {
  
  final String image;

  const Users_image_with_active({Key key, this.image}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        CircleAvatar(
          backgroundImage: AssetImage(image),
        ),
        
        Positioned(
          child:Container(
          width: 15,
          height: 15,
          decoration: BoxDecoration(
            color: Colors.green,
            borderRadius: BorderRadius.circular(20),
          ),
        ), 
          right: 0,
          top: 25,
          
        )
      ],
    );
  }
}

