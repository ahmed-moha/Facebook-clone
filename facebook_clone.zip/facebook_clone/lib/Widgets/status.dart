import 'package:facebook_clone/export.dart';
class Status_posts extends StatelessWidget {
  
final String images , names;

  const Status_posts({Key key, this.images, this.names}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        
        Container(
          width: size.width * 0.3,
          height: size.width * 0.4 + 15,
          decoration: BoxDecoration(
              color: KprimaryColor,
              image: DecorationImage(
                  image: AssetImage(images),
                  fit: BoxFit.cover),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                    offset: Offset(0, 10),
                    blurRadius: 20,
                    color: KprimaryColor)
              ]),
          child: Stack(
            children: [
              Positioned(
                child: CircleAvatar(
                  backgroundImage:
                      AssetImage(images),
                  radius: 25,
                ),
                left: 5,
                top: 5,
              ),
              Positioned(
                child: Text(names,
                    style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Source Sans Pro',
                        fontWeight: FontWeight.normal,
                        color: Colors.white)),
                top: 150,
                left: 15,
              )
            ],
          ),
        )
      ],
    );
  }
}
