import 'package:facebook_clone/export.dart';
class Post extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(top: 20, left: 10),
                child: CircleAvatar(
                  backgroundImage: AssetImage("assets/images/ahmed.jpg"),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 10, top: 2),
                    child: Text(
                      "Ahmed Mohamed",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  Row(
                    children: [
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Icon(
                          Icons.star,
                          size: 15,
                          color: Colors.grey,
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 2),
                        child: Text(
                          "Favorites",
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                      Container(
                        child: Text(
                          "  2h",
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 10),
                        child: Icon(
                          FontAwesomeIcons.globeAfrica,
                          size: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              )
            ],
          ),
          Row(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(left: 15, top: 10),
                    child: Text(
                        "hello guys this is my flutter facebook clone\n Welcom to Open Hands"),
                  ),
                  SizedBox(height: 10),
                  Container(
                    margin: EdgeInsets.only(left: 15),
                    width: 380,
                    height: 250,
                    child: Image.asset(
                      "assets/images/ahmed.jpg",
                      fit: BoxFit.fill,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                width: 100,
                height: 50,
                child: Row(
                  children: [
                    Container(
                      width: 50,
                      child: Image.asset("assets/images/re.png"),
                    ),
                    Container(
                      child: Text("291"),
                    )
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left:80),
                child: Text("17 Comments"),
              ),
              Container(
                margin: EdgeInsets.only(left:60),
                child: Text("5 Share"),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: Second_Top_Header(
                  icon1: Icons.thumb_up_alt_outlined,
                  color1: Colors.red[900],
                  name1: "Like",
                  icon2: FontAwesomeIcons.comment,
                  color2: Colors.green,
                  name2: "Comment",
                  icon3: FontAwesomeIcons.share,
                  color3: Colors.purple,
                  name3: "Share",
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
