import 'package:facebook_clone/export.dart';

class List_of_users extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
          OutlinedButton.icon(onPressed: (){}, icon: Icon(Icons.video_call_sharp), label: Text("Create \nRoom")),
          Users_image_with_active(image: "assets/images/ahmed.jpg"),
          Users_image_with_active(image: "assets/images/baabale.jpg"),
          Users_image_with_active(image: "assets/images/qaanda.jpg"),
          Users_image_with_active(image: "assets/images/qoryooleey.jpg"),
          Users_image_with_active(image: "assets/images/mulki.jpg"),
          
      ],
    );
  }
}