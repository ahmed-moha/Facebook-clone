import 'package:facebook_clone/export.dart';

class Second_Top_Header extends StatelessWidget {
  
  final IconData icon1,icon2,icon3;
  final String name1,name2,name3;
  final Color color1,color2,color3;

   const Second_Top_Header({Key key, this.name1, this.name2, this.name3, this.icon1, this.icon2, this.icon3, this.color1, this.color2, this.color3}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        FlatButton.icon(
          onPressed: () {},
          icon: Icon(
            icon1,
            color: color1,
          ),
          label: Text(name1),
          color: Colors.white,
        ),
        Container(
          width: 1,
          height: 20,
          color: Colors.grey,
        ),
        FlatButton.icon(
            onPressed: () {},
            icon: Icon(
              icon2,
              color:color2
            ),
            label: Text(name2)),
        Container(
          width: 1,
          height: 20,
          color: Colors.grey,
        ),
        FlatButton.icon(
            onPressed: () {},
            icon: Icon(
              icon3,
              color: color3,
            ),
            label: Text(name3))
      ],
    );
  }
}
