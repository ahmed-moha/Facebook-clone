import 'package:facebook_clone/export.dart';
class Create_story extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: size.width*0.3,
      height: size.width*0.4+15,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            offset: Offset(0,10),
            blurRadius: 20,
            color: KprimaryColor
          )
        ]
      ),
      child: Stack(
        children: [
         ClipRRect(
           borderRadius: BorderRadius.circular(12),
           child:  Image.asset("assets/images/ahmed.jpg"),
         ),
          Positioned(
            child: Column(
              children: [
                Icon(Icons.add_circle,color: KprimaryColor,size: 30,),
                Text("Create a\n  Story")
              ],
              
            ),
            top: 115,
            left: 35,
          )
        ],
      ),
    );
  }
}



