import 'package:facebook_clone/export.dart';

class CenterHome extends StatelessWidget {
  const CenterHome({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Top_Header(),Divider(thickness: 1,),
          Second_Top_Header(
            icon1: Icons.video_call_sharp,
            color1: Colors.red[900],
            name1: "Live",
            icon2: Icons.image,
            color2: Colors.green,
            name2: "Photo",
            icon3: Icons.video_call_sharp,
            color3: Colors.purple,
            name3: "Room",
          ),
          Divider(thickness: 10,),
          List_of_users(),Divider(thickness: 9,),
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Create_story(),Status_posts(images: "assets/images/qoryooleey.jpg",names: "Sharfanne",),
                Status_posts(
                  images: "assets/images/ahmed.jpg",names: "ahmed Moha",),],), ),SizedBox(height: 20,),Divider(thickness: 20,),Post(),],),));}}

