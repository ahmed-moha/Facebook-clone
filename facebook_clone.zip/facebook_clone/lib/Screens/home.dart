import 'package:facebook_clone/Screens/center.dart';
import 'package:facebook_clone/export.dart';

class Home extends StatelessWidget {
  Home({Key key}) : super(key: key);

  PageController controller = PageController();
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);
    return Scaffold(
      appBar: AppBar(
        brightness: Brightness.light,
        title: Text("Facebook",
            style: TextStyle(
                fontFamily: 'Source Sans Pro',
                fontSize: 30.0,
                color: KprimaryColor)),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(
              Icons.search,
              color: Colors.black,
              size: 25,
            ),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(
              FontAwesomeIcons.facebookMessenger,
              color: Colors.black,
              size: 20,
            ),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(30.0),
          child: TabbarHeader(
            backgroundColor: Colors.white,
            indicatorColor: KprimaryColor,
            foregroundColor: KprimaryColor,
            controller: controller,
            tabs: [
              Tab(
                  child: Icon(
                Icons.home,
                color: Colors.grey[600],
              )),
              Tab(
                child: Icon(
                  Icons.people,
                  color: Colors.grey[600],
                ),
              ),
              Tab(
                child: Icon(
                  Icons.group,
                  color: Colors.grey[600],
                ),
              ),
              Tab(
                child: FaIcon(
                  FontAwesomeIcons.userCircle,
                  color: Colors.grey[600],
                ),
              ),
              Tab(
                child: FaIcon(
                  FontAwesomeIcons.bell,
                  color: Colors.grey[600],
                ),
              ),
              Tab(
                child: Icon(
                  Icons.menu,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
      body: TabbarContent(controller: controller, children: [
        CenterHome(),
        Container(
          color: Colors.cyan,
        ),
        Container(
          color: Colors.pink,
        ),
        Container(
          color: Colors.brown,
        ),
        Container(
          color: Colors.yellow,
        ),
        Container(
          color: Colors.blueAccent,
        ),
      ]),
    );
  }
}
